<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>TELEKUNG SITI KHADIJAH</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Bootstrap CSS -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
body {
  font-family: 'Times New Roman', Times, Serif;
  margin: 0;
  padding: 0;
  background-color: #ece6d8;
  color: black;
}

header {
  background-color: #6a766c; /* Adjusted color to match homepage */
  color: white;
  padding: 10px 0;
  position: relative;
  display: flex;
  justify-content: center; /* Center content horizontally */
  align-items: center; /* Center content vertically */
}

.menu-icon {
  position: absolute;
  top: 10px;
  left: 10px;
  cursor: pointer;
  color: white;
  font-size: 24px;
}

.menu-icon:hover {
  color: #ccc;
}

.sidebar {
  position: fixed;
  top: 0;
  left: 0;
  height: 100%;
  width: 220px;
  background-color: #4a5245;
  padding-top: 20px;
}

.sidebar a {
  padding: 10px;
  font-size: 18px;
  color: white;
  display: block;
  text-decoration: none;
}

.sidebar a:hover {
  background-color: #c6d1c8;
}

.dropdown {
  position: relative;
}

.dropdown-menu {
  display: none;
  position: absolute;
  background-color: #4a5245;
  padding: 10px 0;
  top: 0;
  left: 100%;
  z-index: 1;
}

.dropdown:hover .dropdown-menu {
  display: block;
}

.dropdown-menu a {
  color: white;
  padding: 10px;
  display: block;
}

#main-content {
  margin-left: 260px; /* Adjust this value to match the width of your sidebar */
  padding: 20px;
}

footer {
  background-color: #4a5245;
  color: white;
  padding: 20px 0;
  margin-top: 20px; /* Added margin-top for spacing */
  text-align: center;
}

/* Styles for product table */
#adminTable {
  width: 100%;
  border-collapse: collapse;
}

#adminTable th, #adminTable td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: left;
}

#adminTable th {
  background-color: #c6d1c8;
}

.low-stock {
  color: red;
}

/* Center the search bar and create button */
#searchContainer {
  text-align: center;
  margin-bottom: 20px; /* Add margin to separate from the table */
}

.create-button {
  display: inline-block; /* Display create button as inline-block */
  margin-bottom: 20px; /* Add margin to separate from the table */
  padding: 10px 20px;
  background-color: #3d85c6; /* Blue color for create button */
  color: white;
  border: none;
  cursor: pointer;
}

/* Style for the edit button */
.edit-button {
  background-color: #4caf50; /* Green color for edit button */
  color: white;
  border: none;
  cursor: pointer;
  padding: 10px;
}

/* Style for the delete button */
.delete-button {
  background-color: #f44336; /* Red color for delete button */
  color: white;
  border: none;
  cursor: pointer;
  padding: 10px;
}

/* Center the title */
h1 {
  margin: 0; /* Remove default margin */
  text-align: center;
}
</style>
</head>
<body>
<header>
  <div class="menu-icon" onclick="toggleSidebar()">&#9776;</div>
  <h1>TELEKUNG SITI KHADIJAH</h1>
</header>

<!-- Sidebar Navigation -->
<div class="sidebar" id="sidebar">
  <!-- Sidebar content goes here -->
  <a href="homepage.html"><i class="fa fa-home"></i> Home</a>
  <div class="dropdown">
    <a class="dropdown-toggle" href="#"><i class="fa fa-shopping-bag"></i> Product</a>
    <div class="dropdown-menu">
      <a href="pro.telekung.php">Telekung</a>
      <a href="pro.sejadah.php">Sejadah</a>
      <a href="pro.assorted.php">Pre-Order</a>
    </div>
  </div>
  <a href="customer.php"><i class="fa fa-user"></i> Customer Order</a>
  <a href="customer_record.php"><i class="fa fa-users"></i> Customer Record</a>
  <a href="user_manual.html"><i class="fa fa-cog"></i> User Manual</a>
</div>

<!-- Main Content -->
<div id="main-content">
  <!-- Paste your product table and related PHP code here -->
  <div id="searchContainer">
    <label for="searchInput">Search:</label>
    <input type="text" id="searchInput" onkeyup="searchProducts()" placeholder="Type to search...">
  </div>

  <table id="adminTable">
    <thead>
      <tr>
        <th>ID</th>
        <th>NAME</th>
        <th>QUANTITY</th>
        <th>PRICE (RM)</th>
        <th>IMAGE </th>
        <th>ACTIONS</th>
      </tr>
    </thead>

    <tbody>
      <?php
        // Connect to your database (replace with your actual database details)
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "product_telekung";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch sejadah from the database
        $sql = "SELECT * FROM products";
        $result = $conn->query($sql);

        // Display each product
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['product_name'] . "</td>";
            echo "<td>";
            if ($row['quantity'] < 10) {
                echo "<span class='low-stock'>" . $row['quantity'] . " - low stock!</span>";
            } else {
                echo $row['quantity'];
            }
            echo "</td>";
            echo "<td>" . $row['price'] . "</td>";
            echo "<td><img src='" . $row['image_path'] . "' alt='Product Image' style='max-width: 100px; max-height: 100px;'></td>";
            echo "<td class='action-buttons'>";
            echo "<button class='edit-button' onclick='editProduct(" . $row['id'] . ")'>Edit</button>";
            echo "<button class='delete-button' onclick='deleteProduct(" . $row['id'] . ")'>Delete</button>";
            echo "</td>";
            echo "</tr>";
        }

        // Close the database connection
        $conn->close();
      ?>
    </tbody>
  </table>

  <button class="create-button" onclick="createProduct()">Create Product</button>
</div>

<!-- Footer -->
<footer>
  &copy; <?php echo date("Y"); ?> TELEKUNG SITI KHADIJAH. All rights reserved.
</footer>

<!-- JavaScript for CRUD operations -->
<script>
  function editProduct(productId) {
    window.location.href = 'editproduct.php?id=' + productId;
  }
  
  function deleteProduct(productId) {
    if (confirm('Are you sure you want to delete this product?')) {
      // Make an AJAX request to delete_product.php
      var xhr = new XMLHttpRequest();
      xhr.open("POST", "delete_product.php", true);
      xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
          alert(xhr.responseText);
          // You may want to reload the page or update the product list here
        }
      };
      xhr.send("id=" + productId);
    }
  }
  
  function createProduct() {
    window.location.href = 'addproduct.html';
  }

  function searchProducts() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("adminTable");
    tr = table.getElementsByTagName("tr");

    // Loop through all table rows, and hide those that don't match the search query
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[1]; // Change index to match the column you want to search
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  function toggleSidebar() {
    var sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
  }
</script>

<!-- jQuery and Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
