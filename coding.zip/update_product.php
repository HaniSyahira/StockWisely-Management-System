<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "product_telekung";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $productId = $_POST['id'];
    $name = $_POST['product_name'];
    $price = $_POST['price'];
    $stock = $_POST['quantity'];

    // Check if a file was uploaded
    if(isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $image_name = $_FILES['image']['name'];
        $image_type = $_FILES['image']['type'];

        // Move uploaded image to desired directory
        $upload_directory = "images/";
        $target_path = $upload_directory . $image_name;

        if(move_uploaded_file($image_tmp_name, $target_path)) {
            // Update database with new image path
            $sql = "UPDATE products SET product_name = '$name', price = '$price', quantity = '$stock', image = '$target_path' WHERE id = '$productId'"; // Enclose $productId in single quotes

            if ($conn->query($sql) === TRUE) {
                echo "Product updated successfully";
            } else {
                echo "Error updating product: " . $conn->error;
            }
        } else {
            echo "Error uploading image";
        }
    } else {
        // No image uploaded, update other fields only
        $sql = "UPDATE products SET product_name = '$name', price = '$price', quantity = '$stock' WHERE id = '$productId'"; // Enclose $productId in single quotes

        if ($conn->query($sql) === TRUE) {
            echo "Product updated successfully";
        } else {
            echo "Error updating product: " . $conn->error;
        }
    }
} else {
    echo "Invalid request";
}

$conn->close();
?>
