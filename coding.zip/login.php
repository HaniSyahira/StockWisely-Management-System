<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>TELEKUNG SITI KHADIJAH</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <style>
    body {
      font-family: 'Times New Roman', Times, Serif;
      margin: 0;
      padding: 0;
      background-color: #;
    }

    header {
      background-color: #4a5245;
      color: #F9F8F8;
      text-align: center;
      padding: 10px 0;
    }

    #mainWrapper {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      padding: 20px;
    }

    .product {
      width: calc(30% - 20px);
      margin-bottom: 20px;
      border: 1px solid #ccc;
      padding: 10px;
      text-align: center;
    }

    .product img {
      max-width: 100%;
      height: auto;
    }

    .quantityLeft {
      font-weight: bold;
      color: darkred;
    }
  </style>
</head>

<body>
  <header>
    <h1>TELEKUNG SITI KHADIJAH</h1>
  </header>

  <div id="mainWrapper">
    <!-- Product 1 -->
    <div class="product">
      <img src="tsk 1.webp" alt="telekung 1" width="220">
      <h3>Modish Mehtap - Mauve&nbsp;&nbsp;</h3>
      <p>Price: RM250.00</p>
      <p>Quantity Left: <span class="quantityLeft">10</span></p>
    </div>

    <!-- Product 2 -->
    <div class="product">
      <img src="tsk 3.webp" alt="telekung 2" width="220">
      <h3>Modish Kralice - Black&nbsp;&nbsp;</h3>
      <p>Price: RM170.90</p>
     <p>Quantity Left: <span class="quantityLeft">5</span></p>
    </div>

    <!-- Product 3 -->
    <div class="product">
      <img src="tsk 12.webp" alt="telekung 3" width="220">
      <h3>Modish Andika - Rose Pink&nbsp;&nbsp;</h3>
      <p>Price: RM530.30</p>
     <p>Quantity Left: <span class="quantityLeft">3</span></p>
    </div>

    <!-- Product 4 -->
    <div class="product">
      <img src="tsk 7.webp" alt="telekung 4" width="220">
      <h3>Broderia Kirana - Peach&nbsp;&nbsp;</h3>
      <p>Price: RM200.70</p>
     <p>Quantity Left: <span class="quantityLeft">12</span></p>
    </div>

    <!-- Product 5 -->
    <div class="product">
      <img src="tsk 8.webp" alt="telekung 5" width="220">
      <h3>Signature Sari Rona Mas&nbsp; &nbsp; -&nbsp; Mauve&nbsp;&nbsp;</h3>
      <p>Price: RM160.60</p>
     <p>Quantity Left: <span class="quantityLeft">4</span></p>
    </div>

    <!-- Product 6 -->
    <div class="product">
      <img src="tsk 9.webp" alt="telekung 6" width="220">
      <h3>Flair Eshal RE - Ash Green&nbsp;&nbsp;</h3>
      <p>Price: RM160.98</p>
     <p>Quantity Left: <span class="quantityLeft">1</span></p>
    </div>

    <!-- Product 7 -->
    <div class="product">
      <img src="tsk 10.webp" alt="telekung 7" width="220">
      <h3>Signature Lurana - Pewter Blue&nbsp;&nbsp;</h3>
      <p>Price: RM190.80</p>
     <p>Quantity Left: <span class="quantityLeft">9</span></p>
    </div>

    <!-- Product 8 -->
    <div class="product">
      <img src="tsk 11.webp" alt="telekung 8" width="220">
      <h3>Signature Defne - White&nbsp; &nbsp;</h3>
      <p>Price: RM145.00</p>
     <p>Quantity Left: <span class="quantityLeft">6</span></p>
    </div>

    <!-- Product 9 -->
    <div class="product">
      <img src="tsk 2.webp" alt="telekung 9" width="220">
      <h3>Signature Kesuma Youth - Mauve&nbsp;&nbsp;</h3>
      <p>Price: RM150.98</p>
     <p>Quantity Left: <span class="quantityLeft">2</span></p>
    </div>
  </div>

  <script>
    document.querySelectorAll('.quantityLeft').forEach(function(element) {
      var quantityLeft = parseInt(element.textContent);
      if (quantityLeft < 5) {
        element.innerHTML += ' - Low Stock!';
      }
    });
  </script>

  <!-- Inventory Analytics Section -->
  <div id="charts-container">
    <canvas id="bar-chart" width="400" height="200"></canvas>
    <canvas id="pie-chart" width="400" height="200"></canvas>
    <canvas id="line-chart" width="400" height="200"></canvas>
  </div>

</body>
</html>
