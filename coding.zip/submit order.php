<?php
// Initialize variables
$customerId = $customerName = $customerNumber = $customerAddress = $productCategory = $selectedProduct  = $quantity = $totalPrice = $orderStatus = $message = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    // Get form data
$customerId = $_POST["customerId"];
$customerName = $_POST["customerName"];
$customerNumber = $_POST["customerNumber"];
$customerAddress = $_POST["customerAddress"];
$productCategory = $_POST["productCategory"];
$selectedProduct = $_POST["selectedProduct"];

$quantity = $_POST["quantity"];
$totalPrice = $_POST["totalPrice"];

    
    // Check if order status is set and not empty
    if (isset($_POST["orderStatus"]) && !empty($_POST["orderStatus"])) {
        $orderStatus = $_POST["orderStatus"];
    } else {
        $orderStatus = "Pending"; // Default order status set to "Pending"
    }

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "product_telekung";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert order data into database
    $sql = "INSERT INTO customer_orders (order_id, customer_name, customer_number, customer_address, productCategory, product, quantity, total_price, order_status)
            VALUES ('$customerId', '$customerName', '$customerNumber', '$customerAddress', '$productCategory', '$selectedProduct','$quantity', '$totalPrice', '$orderStatus')";

    if ($conn->query($sql) === TRUE) {
        $message = "New record created successfully";
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Submit Order - Stockwisely Management System</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <div class="container">
      <h2 class="mt-4 mb-4">Order Details</h2>
      <table class="table table-bordered">
          <tbody>
              <tr>
                  <th>Customer ID</th>
                  <td><?php echo $customerId; ?></td>
              </tr>
              <tr>
                  <th>Customer Name</th>
                  <td><?php echo $customerName; ?></td>
              </tr>
              <tr>
                  <th>Customer Number</th>
                  <td><?php echo $customerNumber; ?></td>
              </tr>
              <tr>
                  <th>Customer Address</th>
                  <td><?php echo $customerAddress; ?></td>
              </tr>
              <tr>
                  <th>Product Category</th>
                  <td><?php echo $productCategory; ?></td>
              </tr>
              <tr>
                  <th>Product</th>
                  <td><?php echo $selectedProduct; ?></td>
              </tr>
          
              <tr>
                  <th>Quantity</th>
                  <td><?php echo $quantity; ?></td>
              </tr>
              <tr>
                  <th>Total Price (RM)</th>
                  <td><?php echo $totalPrice; ?></td>
              </tr>
              <tr>
                  <th>Order Status</th>
                  <td><?php echo $orderStatus; ?></td>
              </tr>
          </tbody>
      </table>
      <?php if (!empty($message)) { ?>
      <div class="mt-4 alert alert-<?php echo ($message == "New record created successfully") ? 'success' : 'danger'; ?>"><?php echo $message; ?></div>
      <?php } ?>
       <!-- Buttons for navigation -->
       <div class="mt-4">
          <a href="customer.php" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back to Customer Page</a>
          <a href="customer_record.php" class="btn btn-info"><i class="fa fa-list"></i> View Customer Records</a>
      </div>
  </div>
</body>
</html>
