<?php
// Check if the request is made using POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve order ID and order status from the POST data
    $order_id = $_POST["order_id"];
    $order_status = $_POST["order_status"];

    // Validate order status to prevent SQL injection
    $valid_statuses = array("Pending", "Processing", "Completed", "Cancelled");
    if (!in_array($order_status, $valid_statuses)) {
        echo "Invalid order status";
        exit;
    }

    // Connect to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "product_telekung";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute SQL statement to update the order status
    $sql = "UPDATE customer_orders SET order_status = ? WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $order_status, $order_id);

    if ($stmt->execute()) {
        echo "Order status updated successfully";
    } else {
        echo "Error updating order status: " . $conn->error;
    }

    // Close the database connection
    $stmt->close();
    $conn->close();
} else {
    // If the request is not made using POST method, return an error
    echo "Invalid request";
}
?>
