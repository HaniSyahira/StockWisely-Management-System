<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customer Record</title>
<style>
/* Add your CSS styles here */
body {
  font-family: 'Times New Roman', Times, Serif;
  margin: 0;
  padding: 0;
  background-color: #ece6d8;
  color: black;
}

header {
  background-color: #6a766c; /* Same as homepage header color */
  color: white;
  text-align: center;
  padding: 10px 0;
}

.container {
  width: 80%;
  margin: 20px auto;
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}

th, td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: left;
}

th {
  background-color: #c6d1c8;
}

.button-container {
  margin-top: 20px;
  text-align: center;
}

.button {
  margin: 0 10px;
  padding: 10px 20px;
  background-color: #6a766c;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}
</style>
</head>
<body>
<header>
<h1>Customer Record</h1>
</header>

<div class="container">
<h2>Customer Orders</h2>
<table id="order-table">
<tr>
<th>Order ID</th>
<th>Customer Name</th>
<th>Customer Number</th>
<th>Customer Address</th>
<th>Product Category</th>
<th>Product</th>
<th>Quantity</th>
<th>Total Price (RM)</th>
<th>Edit Order Status</th>
</tr>
<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "product_telekung";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve customer orders
$sql = "SELECT * FROM customer_orders";
$result = $conn->query($sql);

// Check if there are any results
if ($result && $result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["order_id"] . "</td>";
        echo "<td>" . $row["customer_name"] . "</td>";
        echo "<td>" . $row["customer_number"] . "</td>";
        echo "<td>" . $row["customer_address"] . "</td>";
        echo "<td>" . $row["productCategory"] . "</td>";
        echo "<td>" . $row["product"] . "</td>";
        echo "<td>" . $row["quantity"] . "</td>";
        echo "<td>" . $row["total_price"] . "</td>";
        // Add dropdown menu for selecting order status
        echo "<td><select class='order-status' data-order-id='" . $row["order_id"] . "'>";
        echo "<option value='Pending'" . ($row["order_status"] == "Pending" ? " selected" : "") . ">Pending</option>";
        echo "<option value='Processing'" . ($row["order_status"] == "Processing" ? " selected" : "") . ">Processing</option>";
        echo "<option value='Completed'" . ($row["order_status"] == "Completed" ? " selected" : "") . ">Completed</option>";
        echo "<option value='Cancelled'" . ($row["order_status"] == "Cancelled" ? " selected" : "") . ">Cancelled</option>";
        echo "</select></td>";
        echo "</tr>";
    }
} else {
    echo "0 results";
}

// Close the database connection
$conn->close();
?>
</table>
</div>

<div class="button-container">
    <button class="button" onclick="updateOrderStatus()">Update Order Status</button>
    <button class="button" onclick="goToHomePage()">Back to Home Page</button>
</div>

<script>
function updateOrderStatus() {
    // Add event listener for change event on order status dropdowns
    const orderStatusDropdowns = document.querySelectorAll('.order-status');
    orderStatusDropdowns.forEach(function(dropdown) {
        // Get the selected order status and order ID
        const selectedStatus = dropdown.value;
        const orderId = dropdown.getAttribute('data-order-id');

        // Send AJAX request to update order status in the database
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'update_order_status.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status === 200) {
                console.log('Order status updated successfully');
                // Reload the page after updating the order status
                location.reload();
            } else {
                console.error('Error updating order status');
            }
        };
        xhr.send('order_id=' + orderId + '&order_status=' + selectedStatus);
    });
}

function goToHomePage() {
    // Redirect to the home page
    window.location.href = 'homepage.html'; // Replace 'home_page.php' with the actual URL of your home page
}
</script>

</body>
</html>
