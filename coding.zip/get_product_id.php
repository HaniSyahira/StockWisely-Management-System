<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "product_telekung";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch next available Product ID
$sql = "SELECT MAX(id) AS max_id FROM products"; 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $next_id = $row["max_id"] + 1; // Increment the maximum product ID by 1
    echo $next_id; // Return the next available Product ID
} else {
    echo "1"; // If no products exist yet, start from 1
}

$conn->close();
?>
