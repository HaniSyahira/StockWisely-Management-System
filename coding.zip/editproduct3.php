<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "product_telekung";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $productId = $_GET['id'];

    // Adjust table name according to your database structure
    $sql = "SELECT * FROM assorted WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Product not found";
        exit();
    }
} elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $productId = $_POST['id'];
    $productName = $_POST['product_name'];
    $price = $_POST['price'];
    $quantity = $_POST['stock'];

    // Adjust table name according to your database structure
    $sql = "UPDATE assorted SET product_name=?, price=?, stock=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sidi", $productName, $price, $quantity, $productId);

    if ($stmt->execute()) {
        echo "<div class='success-box'>";
        echo "<div class='success-message'>Your edit is successful!</div>";
        echo '<div class="back-button"><a href="pro.assorted.php"><button>Back to Product Page</button></a></div>';
        echo "</div>";
        exit(); // Stop further execution
    } else {
        echo "Error updating record: " . $stmt->error;
    }
} else {
    echo "Invalid request";
    exit();
}

$conn->close();
?>
