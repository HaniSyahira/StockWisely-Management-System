<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Create Product - eCommerce Website</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family: 'Times New Roman',Times, Serif;
      background-color:  #ece6d8;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #4a5245;
      color: white;
      text-align: center;
      padding: 1em;
    }

    form {
      max-width: 400px;
      margin: 20px auto;
      background-color: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    label {
      display: block;
      margin-bottom: 8px;
    }

    input {
      width: 100%;
      padding: 8px;
      margin-bottom: 16px;
      box-sizing: border-box;
    }

    input[type="submit"] {
      background-color: #6aa84f;
      color: #fff;
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: black;
    }
  </style>
</head>

<body>
  <header>
    <h1>Let's Create Product!</h1>
  </header>

  <form action="addproduct.html" method="post">
    <label for="productName">Name:</label>
    <input type="text" id="productName" name="name" required><br>

    <label for="productPrice">Price:</label>
    <input type="number" id="productPrice" name="price" step="0.01" required><br>

    <label for="productStock">Stock:</label>
    <input type="number" id="productStock" name="stock" required><br>

    <!-- Add more fields if needed -->

    <input type="submit" value="Add Product">
  </form>
</body>
</html>
