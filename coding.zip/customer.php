<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Stockwisely Management System</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- jQuery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <style>
      body {
          background-color: #ece6d8;
          font-family: 'Times New Roman', Times, Serif;
      }

      .sidebar {
          position: fixed;
          top: 0;
          left: 0;
          height: 100%;
          width: 220px;
          background-color: #4a5245;
          padding-top: 20px;
      }

      .sidebar a {
          padding: 10px;
          font-size: 18px;
          color: white;
          display: block;
          text-decoration: none;
      }

      .sidebar a:hover {
          background-color: #c6d1c8;
      }

      .main-content {
          margin-left: 260px;
          padding: 20px;
      }

      .navbar {
          background-color: #6a766c;
          color: white;
          text-align: center;
          padding: 10px 0;
      }

      footer.footer {
          background-color: #4a5245;
          color: white;
          padding: 20px 0;
          margin-top: 20px;
          text-align: center;
      }

      footer.footer p {
          margin-bottom: 0;
      }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar">
      <a href="homepage.html"><i class="fa fa-home"></i> Home</a>
      <div class="dropdown">
          <a class="dropdown-toggle" href="#" id="productDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fa fa-shopping-bag"></i> Product
          </a>
          <div class="dropdown-menu" aria-labelledby="productDropdown">
              <a class="dropdown-item" href="pro.telekung.php">Telekung</a>
              <a class="dropdown-item" href="pro.sejadah.php">Sejadah</a>
              <a class="dropdown-item" href="pro.assorted.php">Pre-Order</a>
          </div>
      </div>
      <a href="customer.php"><i class="fa fa-user"></i> Customer Order</a>
      <a href="customer_record.php"><i class="fa fa-users"></i> Customer Record</a>
      <a href="user_manual.html"><i class="fa fa-cog"></i> User Manual</a>
  </div>

  <!-- Main Content -->
  <div class="main-content">
      <!-- Navigation Bar -->
      <nav class="navbar navbar-expand-md navbar-dark">
          <div class="container">
              <a class="navbar-brand" href="#"><i class="fa fa-cubes"></i> STOCKWISELY MANAGEMENT SYSTEM</a>
          </div>
      </nav>

      <!-- Customer Page Content -->
      <header>
          <h1 class="text-center">Customer Page</h1>
      </header>

      <div class="container">
          <div class="row justify-content-center">
              <div class="col-md-8">
                  <div class="card">
                      <div class="card-header">Fill Customer Details and Place Order</div>
                      <div class="card-body">
                          <form id="orderForm" action="submit order.php" method="post">
                              <div class="form-group">
                                  <label for="customerId">Customer ID:</label>
                                  <input type="text" class="form-control" id="customerId" name="customerId" readonly>
                              </div>

                              <div class="form-group">
                                  <label for="customerName">Customer Name:</label>
                                  <input type="text" class="form-control" id="customerName" name="customerName" required>
                              </div>

                              <div class="form-group">
                                  <label for="customerNumber">Customer Number:</label>
                                  <input type="text" class="form-control" id="customerNumber" name="customerNumber" required>
                              </div>

                              <div class="form-group">
                                  <label for="customerAddress">Customer Address:</label>
                                  <textarea class="form-control" id="customerAddress" name="customerAddress" required></textarea>
                              </div>

                              <div class="form-group">
                                  <label for="productCategory">Product Category:</label>
                                  <select class="form-control" id="productCategory" name="productCategory" onchange="fetchProducts()" required>
                                      <option value="">Select a category</option>
                                      <option value="telekung">Telekung</option>
                                      <option value="sejadah">Sejadah</option>
                                      <option value="preorder">Pre-Order</option>
                                  </select>
                              </div>

                              <div class="form-group">
    <label for="product">Product:</label>
    <select class="form-control" id="product" name="selectedProduct" required onchange="calculateTotalPrice()">
        <!-- Product options will be dynamically inserted here -->
    </select>
</div>

<div class="form-group">
    <label for="productPriceDisplay">Product Price (RM):</label>
    <div class="input-group">
        <div class="input-group-append">
            <span class="input-group-text">RM</span>
        </div>
        <span class="form-control" id="productPriceDisplay" readonly></span>
        <!-- Hidden input field to pass the value to PHP -->
        <input type="hidden" id="hiddenProductPriceDisplay" name="productPriceDisplay">

    </div>
</div>


                                <div class="form-group">
    <label for="quantity">Quantity:</label>
    <input type="number" class="form-control" id="quantity" name="quantity" min="1" max="10" required oninput="calculateTotalPrice()">
</div>

<!-- Total Price Display -->
<div class="form-group">
    <label for="totalPrice">Total Price (RM):</label>
    <input type="text" class="form-control" id="totalPrice" name="totalPrice" readonly>
</div>

                              <button type="submit" class="btn btn-primary">Place Order</button>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      <!-- Footer -->
      <footer class="footer">
          <div class="container text-center">
              <p>&copy; <?php echo date("Y"); ?> StockWisely Management System. All rights reserved.</p>
              <div class="social-icons">
                  <a href="#"><i class="fa fa-facebook"></i></a>
                  <a href="#"><i class="fa fa-twitter"></i></a>
                  <a href="#"><i class="fa fa-instagram"></i></a>
              </div>
          </div>
      </footer>
  </div>

  <!-- JavaScript for fetching products -->
  <script>
      // Function to generate customer ID
      function generateCustomerId() {
          var customerId = Math.floor(1000 + Math.random() * 9000);
          document.getElementById("customerId").value = customerId;
      }

      // Function to calculate total price
      function calculateTotalPrice() {
    var productPrice = parseFloat(document.getElementById("product").value);
    var quantity = parseFloat(document.getElementById("quantity").value);
    var totalPrice = productPrice * quantity;
    
    // Display the total price
    if (!isNaN(totalPrice)) {
        document.getElementById("totalPrice").value = totalPrice.toFixed(2);
    } else {
        document.getElementById("totalPrice").value = "0.00";
    }
}
// Function to fetch product price
// Function to fetch product price
// Function to fetch product price
// Function to fetch product price
function fetchProductPrice() {
    var productSelect = document.getElementById("product");
    var selectedOption = productSelect.options[productSelect.selectedIndex];
    var selectedProductPrice = parseFloat(selectedOption.getAttribute('data-price')).toFixed(2);
    
    // Display the product price
    document.getElementById("productPriceDisplay").innerText = selectedProductPrice;
    
    // Set the value of the hidden input field
    document.getElementById("hiddenProductPriceDisplay").value = selectedProductPrice; // Ensure this line is correct
}





      // Function to fetch products
    // Function to calculate total price
function calculateTotalPrice() {
    var productSelect = document.getElementById("product");
    var selectedOption = productSelect.options[productSelect.selectedIndex];
    var productPrice = parseFloat(selectedOption.getAttribute('data-price'));
    var quantity = parseFloat(document.getElementById("quantity").value);
    var totalPrice = productPrice * quantity;
    
    // Display the product price
    document.getElementById("productPriceDisplay").innerText = productPrice.toFixed(2);

    // Display the total price
    if (!isNaN(totalPrice)) {
        document.getElementById("totalPrice").value = totalPrice.toFixed(2);
    } else {
        document.getElementById("totalPrice").value = "0.00";
    }
}


// Function to fetch products
// Function to fetch products
// Function to fetch products
function fetchProducts() {
    var productCategory = document.getElementById("productCategory").value;
    var productSelect = document.getElementById("product");

    // AJAX request to fetch products based on category
    $.ajax({
        url: "fetch_products.php",
        type: "POST",
        data: { category: productCategory },
        success: function(data) {
            // Insert fetched product options into the select dropdown
            productSelect.innerHTML = data;
            // Fetch product price when products are fetched
            fetchProductPrice();
            // Calculate total price when products are fetched
            calculateTotalPrice();
        }
    });
}


      // Generate customer ID when the page loads
      generateCustomerId();
  </script>
</body>
</html>
