<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "product_telekung";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch product names and prices based on category
if(isset($_POST['category'])) {
    $category = $_POST['category'];
    
    switch ($category) {
        case 'telekung':
            $table = 'products';
            break;
        case 'sejadah':
            $table = 'sejadah';
            break;
        case 'preorder':
            $table = 'assorted';
            break;
        default:
            $table = '';
            break;
    }

    if (!empty($table)) {
        $sql = "SELECT product_name, price FROM $table";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                // Echo option with data-price attribute
                echo "<option value='" . $row["product_name"] . "' data-price='" . $row["price"] . "'>" . $row["product_name"] . "</option>";
            }
        } else {
            echo "<option value=''>No products available</option>";
        }
    } else {
        echo "<option value=''>No products available</option>";
    }
}

// Close database connection
$conn->close();
?>
