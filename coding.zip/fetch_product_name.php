<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "product_telekung";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get product ID from POST data
$productId = $_POST["productId"];

// Fetch product name based on product ID
$sql = "SELECT productName FROM products WHERE productId = '$productId'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Send product name as response
    echo $row["productName"];
} else {
    echo "Product not found";
}

// Close database connection
$conn->close();
?>
