<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Edit Product - SEJADAH SITI KHADIJAH</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body {
  font-family: 'Times New Roman', Times, Serif;
  background-color: #ece6d8;
  margin: 0;
  padding: 0;
}

.container {
  max-width: 400px;
  margin: 20px auto;
  background-color: #f1ece6; /* Light beige color */
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
  text-align: center;
  color: #6a766c; /* Dark green color */
}

form {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 8px;
}

input {
  width: 100%;
  padding: 8px;
  margin-bottom: 16px;
  box-sizing: border-box;
}

button {
  background-color: #6a766c; /* Dark green color */
  color: #fff;
  padding: 10px 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #4a5245; /* Dark green color */
}

.success-box {
  text-align: center;
  margin-top: 20px;
}

.success-message {
  background-color: #3d9970; /* Turquoise color */
  color: #fff;
  padding: 10px 15px;
  border-radius: 4px;
  display: inline-block;
}

.back-button {
  margin-top: 10px;
}
</style>
</head>

<body>
<div class="container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "product_telekung";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $productId = $_GET['id'];

    // Adjust table name according to your database structure
    $sql = "SELECT * FROM sejadah WHERE id = $productId";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Product not found";
        exit();
    }
} elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $productId = $_POST['id'];
    $productName = $_POST['product_name'];
    $price = $_POST['price'];
    $quantity = $_POST['stock'];

    // Adjust table name according to your database structure
    $sql = "UPDATE sejadah SET product_name='$productName', price=$price, stock=$quantity WHERE id=$productId";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='success-box'>";
        echo "<div class='success-message'>Your edit is successful!</div>";
        echo '<div class="back-button"><a href="pro.sejadah.php"><button>Back to Product Page</button></a></div>';
        echo "</div>";
        exit(); // Stop further execution
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    echo "Invalid request";
    exit();
}
?>

<h2>Edit Product</h2>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
  <label for="product_name">Name:</label>
  <input type="text" name="product_name" value="<?php echo $row['product_name']; ?>" required><br>

  <label for="price">Price (RM):</label>
  <input type="number" name="price" value="<?php echo $row['price']; ?>" step="0.01" required><br>

  <label for="quantity">Stock:</label>
  <input type="number" name="stock" value="<?php echo $row['stock']; ?>" required><br>

  <label for="image_path">Image:</label>
  <input type="file" name="image" accept="image/*"><br>

  <button type="submit">Save Changes</button>
</form>
</div>

<?php
$conn->close();
?>
</body>
</html>
