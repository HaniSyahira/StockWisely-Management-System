<?php
// Replace these with your actual database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "product_telekung";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$data = [];
$sql = "SELECT product_name, stock FROM assorted";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[$row['product_name']] = $row['stock'];
    }
}

// Close connection
$conn->close();

// Output JSON
header('Content-Type: application/json');
echo json_encode($data);
?>
