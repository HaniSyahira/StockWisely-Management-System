<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all form fields are set and not empty
    if (isset($_POST["productName"]) && isset($_POST["quantity"]) && isset($_POST["price"]) && isset($_FILES["image"])) {
        // Get form data
        $productName = $_POST["productName"];
        $quantity = $_POST["quantity"];
        $price = $_POST["price"];
        $image = $_FILES["image"];

        // Validate the image file
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($image["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if the file is an actual image
        $check = getimagesize($image["tmp_name"]);
        if ($check !== false) {
            // Check if the file already exists
            if (file_exists($target_file)) {
                echo "Sorry, file already exists.";
            } else {
                // Upload the file
                if (move_uploaded_file($image["tmp_name"], $target_file)) {
                    // Perform database insertion
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "product_telekung";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Prepare SQL statement
                    $sql = "INSERT INTO products (product_name, quantity, price, image_path) VALUES (?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sids", $productName, $quantity, $price, $target_file);

                    // Execute the statement
                    if ($stmt->execute()) {
                        echo "Product added successfully.";
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }

                    // Close connection
                    $conn->close();
                } else {
                    echo "Sorry, there was an error uploading your file.";
                }
            }
        } else {
            echo "File is not an image.";
        }
    } else {
        echo "Form data is incomplete.";
    }
} else {
    echo "Form submission method is not POST.";
}
?>
